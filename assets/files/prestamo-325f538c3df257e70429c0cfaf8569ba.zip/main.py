from centro import CentroPrestamo
from carga_datos import cargar_usuarios, cargar_materiales, cargar_prestamos, guardar_prestamos


def mostrar_usuarios(centro):
    print("\nUSUARIOS CARGADOS")
    print("-" * 40)

    for usuario in centro.usuarios.values():
        print(usuario)


def mostrar_materiales(centro):
    print("\nMATERIALES CARGADOS")
    print("-" * 40)

    for material in centro.materiales.values():
        print(material)


def mostrar_prestamos(centro):
    print("\nPRESTAMOS ACTUALES")
    print("-" * 40)

    if len(centro.prestamos) == 0:
        print("No hay prestamos registrados.")
    else:
        for prestamo in centro.prestamos:
            print(prestamo)


def mostrar_materiales_disponibles(centro):
    print("\nMATERIALES DISPONIBLES")
    print("-" * 40)

    disponibles = centro.materiales_disponibles()

    if len(disponibles) == 0:
        print("No hay materiales disponibles.")
    else:
        for material in disponibles:
            print(material)


def mostrar_usuarios_con_penalizacion(centro):
    print("\nUSUARIOS CON PENALIZACION")
    print("-" * 40)

    usuarios = centro.usuarios_con_penalizacion()

    if len(usuarios) == 0:
        print("No hay usuarios con penalizacion.")
    else:
        for usuario in usuarios:
            print(usuario)


def probar_metodos_centro(centro):
    print("\nPRUEBAS DE METODOS DEL CENTRO")
    print("-" * 40)

    try:
        material = centro.material_mas_valioso()
        print("Material mas valioso:")
        print(material)
    except ValueError as error:
        print(f"Error al obtener el material mas valioso: {error}")

    print(f"Valor total de materiales: {centro.valor_total_materiales()} euros")
    print(f"Tipo con mas prestamos: {centro.tipo_con_mas_prestamos()}")


def probar_prestamos_adicionales(centro):
    print("\nPRUEBAS DE PRESTAMOS ADICIONALES")
    print("-" * 40)

    try:
        centro.realizar_prestamo("U004", "M003", 6)
        print("Prestamo realizado correctamente: U004 -> M003")
    except ValueError as error:
        print(f"No se pudo realizar el prestamo U004 -> M003: {error}")

    try:
        centro.realizar_prestamo("U003", "M003", 5)
        print("Prestamo realizado correctamente: U003 -> M003")
    except ValueError as error:
        print(f"No se pudo realizar el prestamo U003 -> M003: {error}")

    try:
        centro.realizar_prestamo("U001", "M002", 4)
        print("Prestamo realizado correctamente: U001 -> M002")
    except ValueError as error:
        print(f"No se pudo realizar el prestamo U001 -> M002: {error}")


def probar_devoluciones(centro):
    print("\nPRUEBAS DE DEVOLUCIONES")
    print("-" * 40)

    try:
        centro.devolver_material("U001", "M001", 2)
        print("Material devuelto correctamente: U001 -> M001 con 2 dias de retraso")
    except ValueError as error:
        print(f"No se pudo devolver el material U001 -> M001: {error}")

    try:
        centro.devolver_material("U002", "M002", 3)
        print("Material devuelto correctamente: U002 -> M002 con 3 dias de retraso")
    except ValueError as error:
        print(f"No se pudo devolver el material U002 -> M002: {error}")

    try:
        centro.devolver_material("U001", "M001", 1)
        print("Material devuelto correctamente: U001 -> M001")
    except ValueError as error:
        print(f"No se pudo devolver el material U001 -> M001: {error}")


def probar_pago_penalizacion(centro):
    print("\nPRUEBA DE PAGO DE PENALIZACION")
    print("-" * 40)

    try:
        centro.pagar_penalizacion("U001", 5)
        print("Pago realizado correctamente: U001 paga 5 euros")
    except ValueError as error:
        print(f"No se pudo realizar el pago de U001: {error}")

    try:
        centro.pagar_penalizacion("U001", 100)
        print("Pago realizado correctamente: U001 paga 100 euros")
    except ValueError as error:
        print(f"No se pudo realizar el pago de U001: {error}")


def probar_polimorfismo(centro):
    print("\nPRUEBA DE POLIMORFISMO")
    print("-" * 40)

    for material in centro.materiales.values():
        penalizacion = material.calcular_penalizacion(3)
        print(f"{material.nombre}: penalizacion con 3 dias de retraso = {penalizacion} euros")


def main():
    centro = CentroPrestamo()

    cargar_usuarios(centro, "data/usuarios.csv")
    cargar_materiales(centro, "data/materiales.csv")
    cargar_prestamos(centro, "data/prestamos.json")

    mostrar_usuarios(centro)
    mostrar_materiales(centro)
    mostrar_prestamos(centro)

    probar_polimorfismo(centro)
    probar_metodos_centro(centro)
    mostrar_materiales_disponibles(centro)
    mostrar_usuarios_con_penalizacion(centro)

    probar_prestamos_adicionales(centro)
    mostrar_prestamos(centro)
    probar_metodos_centro(centro)

    probar_devoluciones(centro)
    mostrar_prestamos(centro)
    mostrar_materiales_disponibles(centro)
    mostrar_usuarios_con_penalizacion(centro)

    probar_pago_penalizacion(centro)
    mostrar_usuarios_con_penalizacion(centro)

    guardar_prestamos(centro, "data/prestamos_salida.json")

    print("\nArchivo prestamos_salida.json generado correctamente.")


if __name__ == "__main__":
    main()
