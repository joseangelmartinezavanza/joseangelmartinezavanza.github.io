from agencia import Agencia
from expediciones import ExpedicionMontana, ExpedicionSelva
from carga_datos import cargar_exploradores, cargar_expediciones, cargar_reservas, guardar_reservas


def mostrar_exploradores(agencia):
    print("\nEXPLORADORES CARGADOS")
    print("-" * 40)

    for explorador in agencia.exploradores.values():
        print(explorador)


def mostrar_expediciones(agencia):
    print("\nEXPEDICIONES CARGADAS")
    print("-" * 40)

    for expedicion in agencia.expediciones.values():
        print(expedicion)


def mostrar_reservas(agencia):
    print("\nRESERVAS ACTUALES")
    print("-" * 40)

    if len(agencia.reservas) == 0:
        print("No hay reservas registradas.")
    else:
        for reserva in agencia.reservas:
            print(reserva)


def mostrar_expediciones_disponibles(agencia):
    print("\nEXPEDICIONES DISPONIBLES")
    print("-" * 40)

    disponibles = agencia.expediciones_disponibles()

    if len(disponibles) == 0:
        print("No hay expediciones disponibles.")
    else:
        for expedicion in disponibles:
            print(expedicion)


def probar_metodos_agencia(agencia):
    print("\nPRUEBAS DE MÉTODOS DE AGENCIA")
    print("-" * 40)

    try:
        expedicion = agencia.expedicion_mas_cara()
        print("Expedición más cara:")
        print(expedicion)
    except ValueError as error:
        print(f"Error al obtener la expedición más cara: {error}")

    print(f"Recaudación total: {agencia.recaudacion_total()} €")
    print(f"Tipo más rentable: {agencia.tipo_mas_rentable()}")


def probar_reservas_adicionales(agencia):
    print("\nPRUEBAS DE RESERVAS ADICIONALES")
    print("-" * 40)

    try:
        agencia.realizar_reserva("EX004", "EP002")
        print("Reserva realizada correctamente: EX004 -> EP002")
    except ValueError as error:
        print(f"No se pudo realizar la reserva EX004 -> EP002: {error}")

    try:
        agencia.realizar_reserva("EX002", "EP005")
        print("Reserva realizada correctamente: EX002 -> EP005")
    except ValueError as error:
        print(f"No se pudo realizar la reserva EX002 -> EP005: {error}")

    try:
        agencia.realizar_reserva("EX001", "EP003")
        print("Reserva realizada correctamente: EX001 -> EP003")
    except ValueError as error:
        print(f"No se pudo realizar la reserva EX001 -> EP003: {error}")


def probar_cancelacion_reserva(agencia):
    print("\nPRUEBA DE CANCELACIÓN DE RESERVA")
    print("-" * 40)

    try:
        agencia.cancelar_reserva("EX005", "EP003")
        print("Reserva cancelada correctamente: EX005 -> EP003")
    except ValueError as error:
        print(f"No se pudo cancelar la reserva EX005 -> EP003: {error}")

    try:
        agencia.cancelar_reserva("EX005", "EP003")
        print("Reserva cancelada correctamente: EX005 -> EP003")
    except ValueError as error:
        print(f"No se pudo cancelar la reserva EX005 -> EP003: {error}")


def probar_polimorfismo(agencia):
    print("\nPRUEBA DE POLIMORFISMO")
    print("-" * 40)

    for expedicion in agencia.expediciones.values():
        print(expedicion.realizar_expedicion())


def main():
    agencia = Agencia()

    cargar_exploradores(agencia, "data/exploradores.csv")
    cargar_expediciones(agencia, "data/expediciones.csv")
    cargar_reservas(agencia, "data/reservas.json")

    mostrar_exploradores(agencia)
    mostrar_expediciones(agencia)
    mostrar_reservas(agencia)

    probar_polimorfismo(agencia)
    probar_metodos_agencia(agencia)
    mostrar_expediciones_disponibles(agencia)

    probar_reservas_adicionales(agencia)
    mostrar_reservas(agencia)
    probar_metodos_agencia(agencia)

    probar_cancelacion_reserva(agencia)
    mostrar_reservas(agencia)
    probar_metodos_agencia(agencia)

    guardar_reservas(agencia, "data/reservas_salida.json")

    print("\nArchivo reservas_salida.json generado correctamente.")


if __name__ == "__main__":
    main()