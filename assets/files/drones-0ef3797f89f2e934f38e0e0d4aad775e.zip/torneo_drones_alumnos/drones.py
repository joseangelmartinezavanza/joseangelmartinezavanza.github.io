class Drone:
    """
    Clase base para los drones del torneo.

    TODO:
    - Implementar atributos privados.
    - Implementar propiedades, getters o setters según corresponda.
    - Validar codigo, modelo, velocidad_maxima y autonomia.
    - Implementar calcular_puntuacion_base() como método polimórfico.
    - Implementar __str__().
    """

    organizacion = "DroneLeague"

    def __init__(self, codigo, modelo, velocidad_maxima, autonomia):
        # TODO: inicializar atributos aplicando validaciones
        pass

    def calcular_puntuacion_base(self):
        # TODO: lanzar NotImplementedError
        pass

    def __str__(self):
        # TODO: devolver "<modelo> - <velocidad_maxima> km/h - <autonomia> min"
        pass


class DroneCarrera(Drone):
    """
    Drone especializado en pruebas de carrera.

    TODO:
    - Añadir atributo aceleracion.
    - Validar que aceleracion sea mayor que 0.
    - Sobrescribir calcular_puntuacion_base().
    """

    def __init__(self, codigo, modelo, velocidad_maxima, autonomia, aceleracion):
        # TODO: llamar al constructor de la clase padre e inicializar aceleracion
        pass

    def calcular_puntuacion_base(self):
        # TODO: velocidad_maxima * 0.6 + aceleracion * 10
        pass


class DroneCarga(Drone):
    """
    Drone especializado en pruebas de carga o resistencia.

    TODO:
    - Añadir atributo capacidad_carga.
    - Validar que capacidad_carga sea mayor que 0.
    - Sobrescribir calcular_puntuacion_base().
    """

    def __init__(self, codigo, modelo, velocidad_maxima, autonomia, capacidad_carga):
        # TODO: llamar al constructor de la clase padre e inicializar capacidad_carga
        pass

    def calcular_puntuacion_base(self):
        # TODO: autonomia * 2 + capacidad_carga * 5
        pass
