class Piloto:
    """
    Representa a un piloto del torneo.

    TODO:
    - Implementar atributos privados.
    - Implementar propiedades, getters o setters según corresponda.
    - Validar id_piloto, nombre, categoria y puntos.
    - Implementar sumar_puntos().
    - Implementar __str__(), __eq__() y __lt__().
    """

    CATEGORIAS_VALIDAS = ["junior", "senior", "pro"]

    def __init__(self, id_piloto, nombre, categoria, puntos=0):
        # TODO: inicializar atributos aplicando validaciones
        pass

    def sumar_puntos(self, cantidad):
        # TODO: sumar puntos validando que cantidad sea un entero mayor que 0
        pass

    def __str__(self):
        # TODO: devolver "<nombre> (<categoria>) - <puntos> puntos"
        pass

    def __eq__(self, other):
        # TODO: comparar pilotos por id_piloto
        pass

    def __lt__(self, other):
        # TODO: comparar pilotos por puntos
        pass
