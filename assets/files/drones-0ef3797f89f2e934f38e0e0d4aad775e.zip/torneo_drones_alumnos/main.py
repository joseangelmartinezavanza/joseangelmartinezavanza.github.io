from torneo import Torneo
from drones import DroneCarrera, DroneCarga
from carga_datos import cargar_pilotos, cargar_pruebas


def mostrar_pilotos(torneo):
    print("\nPILOTOS CARGADOS")
    print("-" * 40)

    for piloto in torneo.pilotos.values():
        print(piloto)


def mostrar_drones(torneo):
    print("\nDRONES CARGADOS")
    print("-" * 40)

    for drone in torneo.drones.values():
        print(drone)
        print(f"Puntuación base: {drone.calcular_puntuacion_base()}")


def mostrar_pruebas(torneo):
    print("\nPRUEBAS CARGADAS")
    print("-" * 40)

    for prueba in torneo.pruebas.values():
        print(f"{prueba.id_prueba} - {prueba.nombre} - {prueba.tipo} - Dificultad: {prueba.dificultad}")


def crear_drones_prueba(torneo):
    drones_prueba = [
        DroneCarrera(
            codigo="D001",
            modelo="Falcon X",
            velocidad_maxima=120,
            autonomia=18,
            aceleracion=6.5
        ),
        DroneCarrera(
            codigo="D002",
            modelo="Rayo Azul",
            velocidad_maxima=105,
            autonomia=20,
            aceleracion=5.8
        ),
        DroneCarga(
            codigo="D003",
            modelo="Atlas Carga",
            velocidad_maxima=70,
            autonomia=40,
            capacidad_carga=8
        ),
        DroneCarga(
            codigo="D004",
            modelo="Titan Box",
            velocidad_maxima=60,
            autonomia=55,
            capacidad_carga=12
        )
    ]

    for drone in drones_prueba:
        torneo.agregar_drone(drone)


def probar_inscripciones(torneo):
    print("\nPRUEBA DE INSCRIPCIONES")
    print("-" * 40)

    operaciones = [
        ("P001", "PR001"),
        ("P003", "PR002"),
        ("P005", "PR003"),
        ("P010", "PR004"),
        ("P001", "PR001"),
        ("P999", "PR001"),
        ("P001", "PR999"),
    ]

    for id_piloto, id_prueba in operaciones:
        try:
            torneo.inscribir_piloto_en_prueba(id_piloto, id_prueba)
            print(f"Inscripción realizada: {id_piloto} -> {id_prueba}")
        except ValueError as error:
            print(f"No se pudo inscribir {id_piloto} -> {id_prueba}: {error}")


def probar_resultados(torneo):
    print("\nPRUEBA DE RESULTADOS")
    print("-" * 40)

    operaciones = [
        ("P001", "D001", "PR001"),
        ("P003", "D004", "PR002"),
        ("P005", "D003", "PR003"),
        ("P010", "D002", "PR004"),
        ("P002", "D001", "PR001"),
        ("P001", "D999", "PR001"),
        ("P001", "D001", "PR999"),
    ]

    for id_piloto, codigo_drone, id_prueba in operaciones:
        try:
            puntos = torneo.registrar_resultado(id_piloto, codigo_drone, id_prueba)
            print(f"Resultado registrado: {id_piloto} obtuvo {puntos} puntos en {id_prueba}")
        except ValueError as error:
            print(f"No se pudo registrar resultado {id_piloto} - {codigo_drone} - {id_prueba}: {error}")


def mostrar_clasificacion(torneo):
    print("\nCLASIFICACIÓN")
    print("-" * 40)

    for posicion, piloto in enumerate(torneo.clasificacion(), start=1):
        print(f"{posicion}. {piloto}")


def probar_metodos_magicos(torneo):
    print("\nPRUEBA DE MÉTODOS MÁGICOS")
    print("-" * 40)

    prueba = torneo.pruebas.get("PR001")
    piloto = torneo.pilotos.get("P001")

    if prueba is not None:
        print(f"Participantes en PR001: {len(prueba)}")

    if prueba is not None and piloto is not None:
        if piloto in prueba:
            print("P001 está inscrito en PR001")
        else:
            print("P001 no está inscrito en PR001")


def probar_estadisticas(torneo):
    print("\nESTADÍSTICAS")
    print("-" * 40)

    print(f"Ganador: {torneo.ganador()}")
    print(f"Media de puntos: {torneo.media_puntos()}")

    print("\nPilotos de categoría pro:")
    try:
        for piloto in torneo.pilotos_por_categoria("pro"):
            print(piloto)
    except ValueError as error:
        print(f"Error: {error}")


def main():
    torneo = Torneo()

    cargar_pilotos(torneo, "data/pilotos.csv")
    cargar_pruebas(torneo, "data/pruebas.csv")
    crear_drones_prueba(torneo)

    mostrar_pilotos(torneo)
    mostrar_drones(torneo)
    mostrar_pruebas(torneo)

    probar_inscripciones(torneo)
    probar_resultados(torneo)
    probar_metodos_magicos(torneo)
    mostrar_clasificacion(torneo)
    probar_estadisticas(torneo)


if __name__ == "__main__":
    main()
