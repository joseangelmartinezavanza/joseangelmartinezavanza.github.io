class Prueba:
    """
    Representa una prueba del torneo.

    TODO:
    - Implementar atributos privados.
    - Implementar propiedades, getters o setters según corresponda.
    - Validar id_prueba, nombre, tipo y dificultad.
    - Implementar inscribir_piloto().
    - Implementar calcular_puntos_prueba().
    - Implementar __len__() y __contains__().
    """

    TIPOS_VALIDOS = ["velocidad", "resistencia", "precision"]

    def __init__(self, id_prueba, nombre, tipo, dificultad):
        # TODO: inicializar atributos aplicando validaciones
        # participantes debe comenzar como una lista vacía
        pass

    def inscribir_piloto(self, piloto):
        # TODO: añadir piloto evitando duplicados
        pass

    def calcular_puntos_prueba(self, drone):
        # TODO: int(drone.calcular_puntuacion_base() / dificultad)
        pass

    def __len__(self):
        # TODO: devolver número de participantes
        pass

    def __contains__(self, piloto):
        # TODO: comprobar si un piloto está inscrito usando __eq__ de Piloto
        pass


class Torneo:
    """
    Gestiona pilotos, drones y pruebas.

    TODO:
    - Implementar atributos privados.
    - Implementar propiedades, getters o setters según corresponda.
    - Implementar todos los métodos indicados en el enunciado.
    """

    def __init__(self):
        # TODO: inicializar diccionarios de pilotos, drones y pruebas
        pass

    def agregar_piloto(self, piloto):
        # TODO: añadir piloto evitando duplicados
        pass

    def agregar_drone(self, drone):
        # TODO: añadir drone evitando duplicados
        pass

    def agregar_prueba(self, prueba):
        # TODO: añadir prueba evitando duplicados
        pass

    def inscribir_piloto_en_prueba(self, id_piloto, id_prueba):
        # TODO: comprobar existencia de piloto y prueba, e inscribir
        pass

    def registrar_resultado(self, id_piloto, codigo_drone, id_prueba):
        # TODO: comprobar existencia, inscripción, calcular puntos y sumarlos
        pass

    def clasificacion(self):
        # TODO: devolver lista de pilotos ordenada de mayor a menor puntuación
        pass

    def ganador(self):
        # TODO: devolver piloto con más puntos o None si no hay pilotos
        pass

    def media_puntos(self):
        # TODO: devolver la media de puntos o 0 si no hay pilotos
        pass

    def pilotos_por_categoria(self, categoria):
        # TODO: validar categoría y devolver pilotos de esa categoría
        pass
