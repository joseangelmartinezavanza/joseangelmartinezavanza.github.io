import csv

from piloto import Piloto
from torneo import Prueba


def cargar_pilotos(torneo, path_fichero):
    """
    Lee pilotos desde un archivo CSV y los añade al torneo.

    Las filas incorrectas deben ignorarse sin detener el programa.

    :param torneo: objeto Torneo que se va a modificar
    :param path_fichero: ruta del archivo pilotos.csv
    :return: objeto torneo modificado
    """
    # TODO: implementar lectura de CSV y creación de objetos Piloto
    return torneo


def cargar_pruebas(torneo, path_fichero):
    """
    Lee pruebas desde un archivo CSV y las añade al torneo.

    Las filas incorrectas deben ignorarse sin detener el programa.

    :param torneo: objeto Torneo que se va a modificar
    :param path_fichero: ruta del archivo pruebas.csv
    :return: objeto torneo modificado
    """
    # TODO: implementar lectura de CSV y creación de objetos Prueba
    return torneo
